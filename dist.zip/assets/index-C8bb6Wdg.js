var f=Object.defineProperty;var p=(a,o,t)=>o in a?f(a,o,{enumerable:!0,configurable:!0,writable:!0,value:t}):a[o]=t;var l=(a,o,t)=>p(a,typeof o!="symbol"?o+"":o,t);(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))r(e);new MutationObserver(e=>{for(const n of e)if(n.type==="childList")for(const s of n.addedNodes)s.tagName==="LINK"&&s.rel==="modulepreload"&&r(s)}).observe(document,{childList:!0,subtree:!0});function t(e){const n={};return e.integrity&&(n.integrity=e.integrity),e.referrerPolicy&&(n.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?n.credentials="include":e.crossOrigin==="anonymous"?n.credentials="omit":n.credentials="same-origin",n}function r(e){if(e.ep)return;e.ep=!0;const n=t(e);fetch(e.href,n)}})();function h(){const a=document.getElementById("confetti-container");if(!a)return;const o=["#FF0000","#00A2FF","#FFC800","#02b84f","#FFFFFF"],t=["circle","square","triangle"];for(let r=0;r<150;r++)setTimeout(()=>{const e=document.createElement("div");e.className="confetti";const n=o[Math.floor(Math.random()*o.length)],s=t[Math.floor(Math.random()*t.length)],i=Math.random()*10+5,u=Math.random()*100;e.style.position="absolute",e.style.backgroundColor=n,e.style.width=`${i}px`,e.style.height=`${i}px`,e.style.left=`${u}%`,e.style.top="0",s==="circle"?e.style.borderRadius="50%":s==="triangle"&&(e.style.width="0",e.style.height="0",e.style.backgroundColor="transparent",e.style.borderLeft=`${i/2}px solid transparent`,e.style.borderRight=`${i/2}px solid transparent`,e.style.borderBottom=`${i}px solid ${n}`);const c=Math.random()*3+2,m=Math.random()*360;e.style.animation=`confettiDrop ${c}s ease-in forwards`,e.style.transform=`rotate(${m}deg)`,a.appendChild(e),setTimeout(()=>{a.contains(e)&&a.removeChild(e)},c*1e3)},r*10)}class y{constructor(o,t,r,e=24){l(this,"endTime");l(this,"hoursElement");l(this,"minutesElement");l(this,"secondsElement");l(this,"intervalId",null);this.hoursElement=document.getElementById(o),this.minutesElement=document.getElementById(t),this.secondsElement=document.getElementById(r),this.endTime=new Date,this.endTime.setHours(this.endTime.getHours()+e)}start(){this.updateDisplay(),this.intervalId=window.setInterval(()=>{this.updateDisplay()},1e3)}updateDisplay(){const o=new Date,t=Math.max(0,this.endTime.getTime()-o.getTime()),r=Math.floor(t/(1e3*60*60)),e=Math.floor(t%(1e3*60*60)/(1e3*60)),n=Math.floor(t%(1e3*60)/1e3);this.hoursElement&&(this.hoursElement.textContent=r.toString().padStart(2,"0")),this.minutesElement&&(this.minutesElement.textContent=e.toString().padStart(2,"0")),this.secondsElement&&(this.secondsElement.textContent=n.toString().padStart(2,"0")),t===0&&this.intervalId!==null&&clearInterval(this.intervalId)}}const d=document.createElement("style");d.textContent=`
  @keyframes confettiDrop {
    0% {
      transform: translateY(0) rotate(0deg);
      opacity: 1;
    }
    80% {
      opacity: 0.8;
    }
    100% {
      transform: translateY(100vh) rotate(720deg);
      opacity: 0;
    }
  }

  @keyframes float-particle {
    0% {
      transform: translate(0, 0) rotate(0deg);
      opacity: 0;
    }
    10% {
      opacity: 1;
    }
    90% {
      opacity: 1;
    }
    100% {
      transform: translate(100px, -100px) rotate(360deg);
      opacity: 0;
    }
  }

  @keyframes shake {
    0%, 100% { transform: translateY(0); }
    25% { transform: translateY(-5px); }
    50% { transform: translateY(5px); }
    75% { transform: translateY(-5px); }
  }

  @keyframes bounce {
    0% {
      transform: translateY(0);
    }
    100% {
      transform: translateY(-10px);
    }
  }

  .animate-bounce {
    animation: bounce 0.6s ease infinite alternate;
  }

  .clicked {
    animation: shake 0.3s;
  }

  .particle {
    position: absolute;
    background-color: rgba(255, 255, 255, 0.8);
    border-radius: 50%;
    pointer-events: none;
    animation: float-particle linear infinite;
  }
`;document.head.appendChild(d);function g(){typeof window.particlesJS<"u"&&window.particlesJS("particles-js",{particles:{number:{value:80,density:{enable:!0,value_area:800}},color:{value:["#FFC800","#FF0000","#00A2FF","#02b84f"]},shape:{type:["circle","triangle","polygon"],stroke:{width:0,color:"#000000"},polygon:{nb_sides:5}},opacity:{value:.7,random:!0,anim:{enable:!1,speed:1,opacity_min:.1,sync:!1}},size:{value:6,random:!0,anim:{enable:!1,speed:40,size_min:.1,sync:!1}},line_linked:{enable:!1},move:{enable:!0,speed:3,direction:"none",random:!0,straight:!1,out_mode:"out",bounce:!1,attract:{enable:!1,rotateX:600,rotateY:1200}}},interactivity:{detect_on:"canvas",events:{onhover:{enable:!0,mode:"repulse"},onclick:{enable:!0,mode:"push"},resize:!0},modes:{grab:{distance:400,line_linked:{opacity:1}},bubble:{distance:400,size:40,duration:2,opacity:8},repulse:{distance:100,duration:.4},push:{particles_nb:4},remove:{particles_nb:2}}},retina_detect:!0})}function b(a,o=5){for(let t=0;t<o;t++){const r=document.createElement("div");r.classList.add("particle");const e=Math.floor(Math.random()*10)+5;r.style.width=`${e}px`,r.style.height=`${e}px`;const n=Math.floor(Math.random()*100),s=Math.floor(Math.random()*100);r.style.left=`${n}%`,r.style.top=`${s}%`;const i=Math.floor(Math.random()*10)+10;r.style.animationDuration=`${i}s`,a.appendChild(r)}}document.addEventListener("DOMContentLoaded",()=>{console.log("DOM loaded, initializing components..."),new y("hours","minutes","seconds").start();try{console.log("Initializing particles..."),g()}catch(e){console.error("Error initializing particles:",e)}const o=document.querySelector(".banner");o&&b(o,8);const t=document.querySelector(".cta-button");t&&(console.log("Adding click handler to button..."),t.addEventListener("click",()=>{t.classList.add("clicked"),console.log("Creating confetti..."),h(),setTimeout(()=>{alert("Congratulations! Your Robux request has been received! 🎮"),t.classList.remove("clicked")},300)})),document.querySelectorAll(".feature").forEach(e=>{e.addEventListener("mouseenter",()=>{const n=e.querySelector(".feature-icon");n&&n.classList.add("animate-bounce")}),e.addEventListener("mouseleave",()=>{const n=e.querySelector(".feature-icon");n&&n.classList.remove("animate-bounce")})})});
